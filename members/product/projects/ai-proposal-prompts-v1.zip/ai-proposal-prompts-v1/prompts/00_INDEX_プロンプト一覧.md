# 提案書自動作成プロンプト集 — Markdown版
**マスターAI会社・シンプル管理版**

作成日：2026-07-23 | 編集者：ハック

---

## 📖 使い方（30秒で理解）

1. 下から番号で探す（#1～#14）
2. 「ファイル場所」の URL をクリック（またはコピー）
3. ファイルを開く → **プロンプト本文をまるごとコピー**
4. ChatGPT / Claude / Gemini のチャットに貼り付け
5. 【インプット】の部分を埋めて送信 → 資料が自動生成される

---

## 📂 プロンプト一覧（全14種類）

### グループ A：コア提案書・診断系

#### #1 提案書11P（Claude版） ⭐⭐ 簡単
- **用途**：特定企業向け営業提案書・11ページ構成
- **特徴**：費用・スケジュール・ROI計算を含む詳細提案書
- **出力形式**：HTML → PDF / PPTX
- **対応AI**：Claude / ChatGPT / Gemini
- **ファイル**：`prompts/prompt_proposal_11p.md`
- **実績**：T9・T10（タナカ工務店提案書）

**使い方の例**：
```
1. prompts/prompt_proposal_11p.md を開く
2. 【インプット】に企業名・現状・目標・費用を埋める
3. Claude / ChatGPT / Gemini に貼り付けて送信
4. HTML提案書が出力される → ブラウザで Ctrl+P でPDF化
↓ 5分で完成！
```

---

#### #2 診断レポート10P（Claude版） ⭐⭐ 簡単
- **用途**：業種別汎用診断レポート・10ページ
- **特徴**：1920×1080px（16:9）でプレゼン形式。セミナー後の読み物・ナーチャリング資料
- **出力形式**：HTML → PDF / PPTX
- **対応AI**：Claude / ChatGPT / Gemini
- **ファイル**：`prompts/prompt_diagnosis_10p.md`
- **実績**：実装済み・複数業種でテスト

**使い方**：
```
1. prompts/prompt_diagnosis_10p.md を開く
2. 【インプット】の「業種」「主な困りごと」を埋める
3. AI に貼り付けて送信 → 各業種の HTML 診断レポートが出力
4. ブラウザで Ctrl+P → PDF / Googleスライドにコピー → セミナー資料に
```

---

#### #3 業務効率化診断プロンプト ⭐⭐ 簡単
- **用途**：#2 と似ているが、より詳細な解説版
- **特徴**：中小企業向けDX・業務改善診断。計算式を含む
- **出力形式**：HTML（1ページ完結）
- **対応AI**：Claude / ChatGPT / Gemini
- **ファイル**：`prompts/prompt_efficiency_diagnosis.md`

---

### グループ B：提案書別バージョン

#### #4 提案書自動生成プロンプト ⭐⭐ 簡単
- **用途**：汎用提案書
- **特徴**：#1 より少し簡略版
- **出力形式**：HTML
- **対応AI**：Claude / ChatGPT / Gemini
- **ファイル**：`prompts/prompt_proposal_auto.md`
- **簡潔版（5ページ）**：`prompts/prompt_proposal_short.md`（時間がないときはこちら）

---

#### #5 AI-Prezen-MakingPrompt ⭐⭐⭐ 中
- **用途**：Gemini特化版（旧版）
- **特徴**：WeasyPrint で PDF 直接生成を想定
- **出力形式**：PDF（直接出力 or HTML）
- **対応AI**：Gemini
- **ファイル**：`prompts/prompt_prezen_making_gemini.md`
- **⚠️ 注意**：Python環境が必要。HTML化への移行推奨

---

#### #6 Gemini版提案書プロンプト ⭐⭐⭐ 中
- **用途**：Gemini固有の最適化実装
- **特徴**：Gemini Code Execution で直接生成
- **出力形式**：HTML / PDF
- **対応AI**：Gemini
- **ファイル**：`prompts/gemini-code-1783929990636.html`

---

### グループ C：スライド・資料系

#### #7 スライド自動生成ヒアリングプロンプト ⭐⭐⭐ 難
- **用途**：5ページPowerPoint資料を対話型で自動生成
- **特徴**：AIとの対話で構成を決定 → PPTX 自動生成
- **出力形式**：PPTX （ChatGPT の python-pptx 実行推奨）
- **対応AI**：**ChatGPT + Code Interpreter** 推奨
- **ファイル**：`prompts/prompt_slide_hearing.md`

**使い方**：
```
営業マンC：「急な営業提案スライドが必要」
ハック：「プロンプト#7を ChatGPT に貼ってください」
ChatGPT：「以下の7つの質問にお答えください」
営業マンC：「（回答）」
ChatGPT：「python-pptx コードを生成しました。このコードをCode Interpreter で実行してください」
→ 5分で PPTX 完成！
```

---

#### #8 A4チラシHTMLプロンプト ⭐⭐ 簡単
- **用途**：A4横（297mm×210mm）チラシを HTML で自動生成
- **特徴**：FieldSyncチラシの実績あり
- **出力形式**：HTML → PDF / PNG（Puppeteer）
- **対応AI**：Claude / ChatGPT / Gemini
- **ファイル**：`prompts/prompt_a4_flyer_corporate.md`（企業向け）/ `prompts/prompt_a4_flyer_freelancer.md`（フリーランス向け）

**実績**：FieldSync チラシ（T6）で PDF / PNG 化完成

---

#### #9 RPA導入ガイド＆製品比較レポート ⭐⭐ 簡単
- **用途**：RPA ツール7つを比較・DX図解・AI+RPA 連携フロー
- **特徴**：7ページの詳細レポート
- **出力形式**：HTML
- **対応AI**：Claude / Gemini
- **ファイル**：`prompts/prompt_rpa_guide.md`（リサーチ資料をそのまま投入）/ 出力サンプル：`samples/sample_rpa_guide.html`

---

### グループ D：テンプレート・ヒアリング系

#### #10 AIエージェント用プロンプトテンプレート ⭐⭐ 中
- **用途**：マルチエージェント・並列実行時の指示文テンプレート
- **特徴**：複数社員に同時指示する際の標準形式
- **出力形式**：Markdown
- **対応AI**：Claude / ChatGPT / Gemini
- **ファイル**：`prompts/prompt_agent_template.md`

---

#### #11 課題整理シート ⭐ 簡単
- **用途**：クライアント向けヒアリングシート
- **特徴**：業務課題を構造化（営業マン→クライアント に配布）
- **出力形式**：Markdown / PDF
- **対応AI**：汎用テンプレート
- **ファイル**：`prompts/prompt_issue_sheet.md`

---

#### #12 応募文テンプレート（記事ライティング） ⭐ 簡単
- **用途**：クラウドソーシング用・ランサーズ向け応募文
- **特徴**：記事執筆案件への標準応募文
- **出力形式**：Markdown
- **対応AI**：汎用テンプレート
- **ファイル**：`prompts/prompt_apply_writing.md`

---

#### #13 応募文テンプレート（提案書・AI文書系） ⭐ 簡単
- **用途**：提案書系案件向け応募文
- **特徴**：差別化ポイント・実績を組み込んだ営業文
- **出力形式**：Markdown
- **対応AI**：汎用テンプレート
- **ファイル**：`prompts/prompt_apply_proposal.md`

---

#### #14 診断プロンプト（Sindanprompt） ⭐ 簡単
- **用途**：簡略版診断レポート
- **特徴**：別形式の診断生成方法・軽量版
- **出力形式**：HTML / Markdown
- **対応AI**：Claude / ChatGPT / Gemini
- **ファイル**：`prompts/prompt_diagnosis_short.md`

---

## 🤖 AI別クイックリファレンス

### Claude で使う
**おすすめプロンプト：** #1, #2, #3, #4, #8, #9
```
✅ HTML 出力に最適
✅ 提案書・診断レポートが得意
⚠️ PDF 化は別途ブラウザ印刷 or スクリプト
❌ PPTX 直接出力はできない（JSON → 変換）
```

### ChatGPT で使う
**おすすめプロンプト：** #1, #2, #7（最適）, #8
```
✅ HTML 出力可能
✅ #7 スライド自動生成が最速（python-pptx + Code Interpreter）
✅ PPTX 出力が得意
⚠️ PDF 化は別途ブラウザ印刷 or Code Interpreter
```

### Gemini で使う
**おすすめプロンプト：** #1, #2, #5, #6, #9
```
✅ HTML 出力可能
✅ #5 WeasyPrint で PDF 直接生成（最速）
✅ Code Execution で自動実行可能
⚠️ PPTX は別途変換
```

---

## 📋 出力形式別・使用形式チェックリスト

### HTML で充分な場合 ✅
- [ ] ブラウザで見せたい
- [ ] メール添付で送りたい（HTML形式）
- [ ] Googleスライドに変換予定

→ **プロンプト：#1, #2, #3, #8, #9**

### PDF で納品する場合 📄
- [ ] 紙で印刷する
- [ ] 固定フォーマットで配布
- [ ] 署名が必要

→ **推奨フロー：**
```
【Claude】HTML 生成 → ブラウザで Ctrl+P → PDF
【ChatGPT】HTML 生成 → Code Interpreter で PDF 生成
【Gemini】"WeasyPrint で PDF を作成" → 直接出力 ⭐ 最速
```

### PPTX で顧客に見せる場合 🎪
- [ ] プレゼンテーションを実施
- [ ] Googleスライドで共有
- [ ] PowerPoint で編集予定

→ **推奨フロー：**
```
【ChatGPT】プロンプト #7 → python-pptx コード → Code Interpreter → PPTX ⭐ 最速
【Claude】HTML 生成 → Googleスライドにコピペ → PPTX ダウンロード
【Gemini】JSON 出力 → ChatGPT Code Interpreter で PPTX 変換
```

### Markdown で内容だけ欲しい場合 📝
- [ ] テンプレートして使う
- [ ] 他ツールで加工予定
- [ ] バージョン管理したい

→ **プロンプト：#10, #11, #12, #13, #14**

---

## 🔧 出力ファイルの保存・変換方法

### HTML → PDF
ブラウザで HTML を開き、**Ctrl+P（Mac: Cmd+P）→「PDFとして保存」** を選択。

### HTML → PPTX
Googleスライドを開いて HTML の内容をコピペ → スライド形式で保存。
または ChatGPT（Code Interpreter）に「この HTML を PPTX に変換して」と依頼。

### PPTX → Googleスライド
Google ドライブに PPTX をアップロード → 「Googleスライドで開く」を選択。

---

## ⚡ 5分でできる仕事・フロー例

### ユースケース 1：「明日までに提案書が必要」（4分）
```
1. 【プロンプト #1】を Claude に貼る（30秒）
2. 【インプット】に企業名・現状・目標を埋める（1分）
3. Claude が HTML 提案書を生成（1分）
4. ブラウザで開いて Ctrl+P で PDF（1分）
5. 完成！ PDF をクライアントに送信
```

### ユースケース 2：「診断レポート 5 業種分を一気に作る」（15分）
```
1. 【プロンプト #2】の【インプット】を業種ごとに埋める（3分）
2. Claude×5 並列実行（実は各1分で完了）
3. 生成された HTML をブラウザで Ctrl+P → PDF 化（5分）
4. Googleスライドにコピペ or アップロード（5分）
5. 営業チームに共有＆セミナー用に使用！
```

### ユースケース 3：「PowerPoint スライドが 5 分で必要」（5分）
```
1. 【プロンプト #7】を ChatGPT に貼る
2. ChatGPT の質問 7 つに回答（2分）
3. ChatGPT が python-pptx コードを生成
4. Code Interpreter で実行（1分）
5. PPTX ダウンロード・プレゼン開始！
```

---

## 📞 FAQ（よくある質問）

### Q. どのプロンプトから始めればいい？
**A.** 以下の順番をおすすめします：
1. **#1 提案書11P**（一番基本・実績多い）
2. **#2 診断レポート10P**（量産向け）
3. **#7 スライド自動生成**（ChatGPT の最大活用）

### Q. 複数業種を一気に生成したい
**A.** プロンプト #2（診断レポート10P）を使い、【インプット】を業種ごとに変えて **並列実行**。15～20分で 5～10 業種分できます。

### Q. PDF 化の品質が悪い場合は？
**A.** ブラウザ印刷（Ctrl+P）ではなく、**Gemini + WeasyPrint** で直接 PDF 生成をお試しください。品質・速度共に最高です。

### Q. PPTX にしたいけど複雑そう
**A.** **ChatGPT + プロンプト #7** が最短です。python-pptx コードを ChatGPT が生成して、Code Interpreter で実行すれば完成。手間は5分。

### Q. 営業マンが各プロンプトを簡単に使えるようにしたい
**A.** このファイルの「プロンプト一覧」を営業マンに共有。番号で指示（「#1 を Claude に送ってね」）だけで OK。ファイルを開かせる手間は省く。

---

## 📊 プロンプト一覧（ファイル対応表）

| # | 名前 | ファイル | 状態 |
|---|---|---|---|
| 1 | 提案書11P | prompt_proposal_11p.md | ✅ |
| 2 | 診断レポート10P | prompt_diagnosis_10p.md | ✅ |
| 3 | 業務効率化診断 | prompt_efficiency_diagnosis.md | ✅ |
| 4 | 提案書自動生成 | prompt_proposal_auto.md | ✅ |
| 5 | AI-Prezen-Making（Gemini） | prompt_prezen_making_gemini.md | ✅ |
| 6 | Gemini版提案書 | gemini-code-1783929990636.html | ✅ |
| 7 | スライド自動生成 | prompt_slide_hearing.md | ✅ |
| 8 | A4チラシ（企業） | prompt_a4_flyer_corporate.md | ✅ |
| 8 | A4チラシ（フリーランス） | prompt_a4_flyer_freelancer.md | ✅ |
| 9 | RPA導入ガイド | prompt_rpa_guide.md | ✅ |
| 10 | AIエージェント用テンプレ | prompt_agent_template.md | ✅ |
| 11 | 課題整理シート | prompt_issue_sheet.md | ✅ |
| 12 | 応募文（記事ライティング） | prompt_apply_writing.md | ✅ |
| 13 | 応募文（提案書・AI文書系） | prompt_apply_proposal.md | ✅ |
| 14 | 診断プロンプト（簡略版） | prompt_diagnosis_short.md | ✅ |

---

## 🚀 はじめての方へ：次のステップ

- [ ] まず **#1（提案書11P）** を Claude か ChatGPT に貼って動作確認
- [ ] 自分がよく使う AI（Claude / ChatGPT / Gemini）を決める
- [ ] よく使うプロンプト 3〜5本を手元にブックマークしておく
- [ ] わからないことがあれば `zodiacm369@gmail.com` へ

---

**最後更新**：2026-08-21  
**バージョン**：1.1  
**サポート**：zodiacm369@gmail.com
